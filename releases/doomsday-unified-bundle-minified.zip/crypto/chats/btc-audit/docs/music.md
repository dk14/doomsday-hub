Here is the sound track set, for context

> a basis for AI audio generation (together with `bird2.html` auto-synthesis and `sefirot.html` in warriors repo)

[UT99](https://archive.org/details/unreal_tournament_ost-1999)
[UT3](https://archive.org/details/unrealtournament3_soundtrack-2007)


UT 2004:
```
StageMusic.ogg
APubWithNoBeer.ogg
Intro_Music.ogg
Jugs-Entrance.ogg
KR-Absolute_Zero.ogg
KR-Action1.ogg
KR-Action2v2.ogg
KR-Action3.ogg
KR-Assault.ogg
KR-Atlantis.ogg
KR-Chemical-Burn.ogg
KR-City.ogg
KR-Collision-Course.ogg
KR-Conduit-v2.ogg
KR-Convoy.ogg
KR-Corrugation-Rise.ogg
KR-DM1.ogg
KR-EndingSequence.ogg
KR-From-Below-v2.ogg
KR-Ghosts-of-Anubis.ogg
KR-Glacier.ogg
KR-HELL.ogg
KR-Hyperblast-Redux.ogg
KR-Infernal-Realm.ogg
KR-Infiltrate.ogg
KR-Junkyard.ogg
KR-MenuMusic-v2.ogg
KR-Metallurgy.ogg
KR-Morpheus3.ogg
KR-Pharaohs-Revenge.ogg
KR-Rankin.ogg
KR-RobotFactory.ogg
KR-Roughinery.ogg
KR-Serenity.ogg
KR-SkaarjAssault.ogg
KR-SkyScraper.ogg
KR-Slaughter.ogg
KR-Sniper-Time.ogg
KR-Sulphur.ogg
KR-Tomb-of-Horus.ogg
KR-UT2003-Menu.ogg
KR-UT2004_Intro_v2.ogg
KR-UT2004-Menu.ogg
KR-WasteLand.ogg
Level2.ogg
Level3.ogg
Level5.ogg
Level6.ogg
Level7.ogg
Level8.ogg
Level9.ogg
Level11.ogg
Level13.ogg
Level15.ogg
Level16.ogg
Menu1.ogg
Mercs-Entrance.ogg
SDG-ONS01.ogg
SDG-ONS02.ogg
SDG-ONS03.ogg
SDG-ONS04.ogg
SDG-ONS05.ogg
SDG-ONS06.ogg
SDG-ONS08.ogg
```
